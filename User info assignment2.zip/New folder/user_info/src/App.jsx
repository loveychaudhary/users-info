import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Container, Form, Table, Button } from 'react-bootstrap';

const UserInfo = () => {
  const [users, setUsers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [pastSearches, setPastSearches] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [showPastSearches, setShowPastSearches] = useState(false);

  // Fetch users from the API
  useEffect(() => {
    axios.get('https://jsonplaceholder.typicode.com/users')
      .then(response => setUsers(response.data))
      .catch(error => console.error('Error fetching users:', error));
  }, []);

  // Retrieve past searches from local storage on component mount
  useEffect(() => {
    const storedSearches = JSON.parse(localStorage.getItem('pastSearches')) || [];
    setPastSearches(storedSearches);
  }, []);

  // Update the filtered users based on the search term
  useEffect(() => {
    const filtered = users.filter(user =>
      user.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredUsers(filtered);
  }, [searchTerm, users]);

  // Handle search term changes
  const handleSearchTermChange = (event) => {
    const term = event.target.value;
    setSearchTerm(term);

    // Update past searches
    if (term.trim() !== '' && !pastSearches.includes(term)) {
      const updatedSearches = [...pastSearches, term];
      setPastSearches(updatedSearches);
      // Save to local storage
      localStorage.setItem('pastSearches', JSON.stringify(updatedSearches));
    }

    // Clear selected user when the search term changes
    setSelectedUser(null);
  };

  // Handle user click
  const handleUserClick = (user) => {
    setSelectedUser(user);
  };

  // Handle sorting by name
  const handleSortByName = () => {
    const sortedUsers = [...filteredUsers].sort((a, b) =>
      a.name.localeCompare(b.name)
    );
    setFilteredUsers(sortedUsers);
  };

  // Handle toggle past searches visibility
  const handleTogglePastSearches = () => {
    setShowPastSearches(!showPastSearches);
  };



return (
  <Container style={{ color: 'white', backgroundColor: 'black', padding: '20px' , height: '94vh' , width: '205vh' }}>
    <div className="d-flex justify-content-center align-items-center flex-column mb-4">
      <h1 style={{ textAlign: 'center' }}>User Info</h1>

      {/* Search bar */}
      <Form.Group style={{ marginBottom: '15px' }}>
        <Form.Control
          type="text"
          placeholder="Search by name"
          value={searchTerm}
          onChange={handleSearchTermChange}
          style={{ width: '70%', marginRight: '10px' }}
        />
        <Button
          variant="secondary"
          onClick={handleTogglePastSearches}
          style={{ width: '25%' }}
        >
          {showPastSearches ? 'Hide Past Searches' : 'Show Past Searches'}
        </Button>
      </Form.Group>

      {/* Past searches */}
      {showPastSearches && pastSearches.length > 0 && (
        <div style={{ marginBottom: '20px' }}>
          <h5 style={{ marginBottom: '10px' }}>Past Searches:</h5>
          <ul style={{ listStyle: 'none', padding: '0' }}>
            {pastSearches.map((search, index) => (
              <li key={index} style={{ marginBottom: '5px' }}>{search}</li>
            ))}
          </ul>
          <Button
            variant="danger"
            onClick={() => {
              setPastSearches([]);
              localStorage.removeItem('pastSearches');
            }}
          >
            Clear Past Searches
          </Button>
        </div>
      )}

      {/* User list */}
      <Table striped bordered hover variant="dark">
        <thead style={{ backgroundColor: 'white', color: 'black' }}>
          <tr>
            <th>Name</th>
            <th>Username</th>
            <th>Email</th>
            <th>Address</th>
            <th>Phone</th>
            <th>Website</th>
            <th>Company</th>
          </tr>
        </thead>
        <tbody>
          {filteredUsers.map(user => (
            <tr
              key={user.id}
              onClick={() => handleUserClick(user)}
              style={{ cursor: 'pointer' }}
            >
              <td>{user.name}</td>
              <td>{user.username}</td>
              <td>{user.email}</td>
              <td>
                {user.address.street}, {user.address.suite}, {user.address.city}, {user.address.zipcode}
              </td>
              <td>{user.phone}</td>
              <td>{user.website}</td>
              <td>{user.company.name}</td>
            </tr>
          ))}
        </tbody>
      </Table>

      {/* Sort button */}
      <Button variant="dark" onClick={handleSortByName} style={{ width: '50%', marginTop: '10px' }}>
        Sort by Name
      </Button>

      {/* Display selected user information */}
      {selectedUser && (
        <div style={{ marginTop: '20px' }}>
          <h2>Selected User: {selectedUser.name}</h2>
          <p>Username: {selectedUser.username}</p>
          <p>Email: {selectedUser.email}</p>
          <p>Address: {selectedUser.address.street}, {selectedUser.address.suite}, {selectedUser.address.city}, {selectedUser.address.zipcode}</p>
          <p>Phone: {selectedUser.phone}</p>
          <p>Website: {selectedUser.website}</p>
          <p>Company: {selectedUser.company.name}</p>
        </div>
      )}
    </div>
  </Container>
);



};

export default UserInfo;
